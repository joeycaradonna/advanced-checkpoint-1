export default {
 searchResults: [],
 myMovieList: []

};
